(function(){
	'use strict';
	angular
	.module('meetMeApp.signup',[]);
})();