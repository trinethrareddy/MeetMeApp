(function(){
	'use strict';
	angular
	.module('meetMeApp.login')
	.controller('loginCtrl',['$scope',function($scope){
		$scope.name ="namratha";
		console.log("123");
	}]);
})();