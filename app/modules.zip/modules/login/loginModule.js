(function(){
	'use strict';
	angular
	.module('meetMeApp.login',[]);
})();